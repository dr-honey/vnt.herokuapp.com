node-grid-demo
==============

Demo of dhtmlxGrid with NodeJs + MongoDB as backend
